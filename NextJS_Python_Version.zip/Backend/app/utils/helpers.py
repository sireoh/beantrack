from fastapi import Request
from app.core.database import engine
from jose import JWTError, jwt
from fastapi import HTTPException, status
from sqlalchemy.orm import sessionmaker
from app.db.models import DBMovieList
from app.core.config import settings
import uuid

SECRET_KEY = settings.secret_key
DEV_MODE = settings.dev_mode

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Helpers:
    """
    Utility class for helper functions.
    """

    @staticmethod
    def generate_uuid() -> str:
        """
        Generate a new UUID string.

        :return: A UUID string.
        """
        return str(uuid.uuid4())

    @staticmethod
    def get_current_movielist_id(user_id: str) -> str:
        """
        Get the movie list ID for the user.

        :param user_id: The user ID.
        :return: The movie list ID.
        :raises HTTPException: If not found.
        """
        with SessionLocal() as session:
            movielist = (
                session.query(DBMovieList)
                .filter(DBMovieList.user_id == user_id)
                .first()
            )
            if not movielist:
                raise HTTPException(status_code=404, detail="Movie list not found")
            return str(movielist.movie_list_id)

    @staticmethod
    def get_current_user(request: Request) -> str:
        """
        Dependency function to get the current authenticated user ID from JWT.

        :param request: The request object.
        :return: The user ID.
        :raises HTTPException: If not authenticated or invalid token.
        """
        token = request.cookies.get("access_token")
        if not token:
            raise HTTPException(status_code=401, detail="Not authenticated")

        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
            user_id: str = payload.get("sub")  # type: ignore
            if user_id is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid token payload",
                )
            return user_id
        except JWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired token",
            )
