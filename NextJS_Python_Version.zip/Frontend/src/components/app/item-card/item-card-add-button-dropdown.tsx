"use client";

import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { TvMinimalPlay, SquareCheckBig, NotebookPen } from "lucide-react";
import { ItemCardDataModel } from "./item-card";
import { useStore } from "@/store";
import { handleTVSelect, handleMovieSelect } from "@/utils/handle-item-select";

const ItemCardAddButtonDropdown = ({
  itemCardData,
}: {
  itemCardData: ItemCardDataModel;
}) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button size="icon" variant="outline" className="size-6 cursor-pointer">
          <Plus />
        </Button>
      </DropdownMenuTrigger>
      <ItemCardAddButtonDropdownContent itemCardData={itemCardData} />
    </DropdownMenu>
  );
};

function ItemCardAddButtonDropdownContent({
  itemCardData,
}: {
  itemCardData: ItemCardDataModel;
}) {
  const search = useStore((state) => state.search);

  async function _t(action: string) {
    handleTVSelect(itemCardData.id!, action);
  }

  async function _m(action: string) {
    handleMovieSelect(itemCardData.imdb!, action);
  }

  const actions = [
    {
      label: "Currently Watching",
      action: "watching",
      icon: <TvMinimalPlay />,
    },
    { label: "Completed", action: "completed", icon: <SquareCheckBig /> },
    { label: "Plan to Watch", action: "plan_to_watch", icon: <NotebookPen /> },
  ];

  const handleSelect = async (action: string) => {
    if (search.currentType === "tv") {
      _t(action);
    } else {
      _m(action);
    }
  };

  return (
    <DropdownMenuContent className="w-48">
      {actions.map(({ label, action, icon }) => (
        <DropdownMenuItem
          key={action}
          onSelect={() => handleSelect(action)}
          className="cursor-pointer">
          {icon}
          {label}
        </DropdownMenuItem>
      ))}
    </DropdownMenuContent>
  );
}

export default ItemCardAddButtonDropdown;
